# test-projects
#include<stdio.h>
#include<conio.h>
void main()
{
int a,b;
printf("enter two numbers");
scanf("%d%d",&a,&b);
}

